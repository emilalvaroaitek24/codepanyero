// Export pages
export '/pages/get_started01/get_started01_widget.dart' show GetStarted01Widget;
export '/pages/get_started02/get_started02_widget.dart' show GetStarted02Widget;
export '/pages/get_started03/get_started03_widget.dart' show GetStarted03Widget;
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/register/register_widget.dart' show RegisterWidget;
export '/pages/homepage/homepage_widget.dart' show HomepageWidget;
export '/pages/wallet/wallet_widget.dart' show WalletWidget;
export '/pages/games/games_widget.dart' show GamesWidget;
export '/pages/services/services_widget.dart' show ServicesWidget;
export '/pages/profile/profile_widget.dart' show ProfileWidget;
export '/ewallet/ewallet_widget.dart' show EwalletWidget;
